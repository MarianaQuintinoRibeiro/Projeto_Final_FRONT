// Aguarda o carregamento completo do conteúdo HTML da página
document.addEventListener('DOMContentLoaded', function() {
  
  // Obtém os elementos necessários da página
  const playButton = document.getElementById('play-button'); // Botão para iniciar o vídeo
  const video = document.getElementById('video'); // Elemento de vídeo
  const videoThumbnail = document.getElementById('video-thumbnail'); // Miniatura do vídeo
  const closeButton = document.getElementById('close-button'); // Botão para fechar o vídeo

  // Adiciona um evento de clique no botão de play
  playButton.addEventListener('click', function() {
      // Quando o botão de play for clicado, esconde a miniatura do vídeo, exibe o vídeo e o botão de fechar, e inicia a reprodução do vídeo
      videoThumbnail.style.display = 'none';
      video.style.display = 'block';
      closeButton.style.display = 'block';
      video.play(); // Inicia a reprodução do vídeo
  });

  // Adiciona um evento de clique no botão de fechar
  closeButton.addEventListener('click', function() {
      // Quando o botão de fechar for clicado, pausa o vídeo, redefine o tempo de reprodução para 0, esconde o vídeo, mostra a miniatura e esconde o botão de fechar
      video.pause(); // Pausa a reprodução
      video.currentTime = 0; // Reinicia o vídeo para o início
      video.style.display = 'none'; // Esconde o vídeo
      videoThumbnail.style.display = 'block'; // Mostra novamente a miniatura
      closeButton.style.display = 'none'; // Esconde o botão de fechar
  });
});

// Função para alternar a classe de um menu (Hambúrguer)
// Essa função é ativada quando o menu de hambúrguer é clicado
function menuOnClick() {
  // Alterna as classes 'change' e 'change-bg' nos elementos correspondentes para exibir ou esconder o menu lateral
  document.getElementById("menu-bar").classList.toggle("change"); // Alterna a classe 'change' no menu lateral
  document.getElementById("nav").classList.toggle("change"); // Alterna a classe 'change' no item de navegação
  document.getElementById("menu-bg").classList.toggle("change-bg"); // Alterna a classe 'change-bg' no fundo do menu
}
