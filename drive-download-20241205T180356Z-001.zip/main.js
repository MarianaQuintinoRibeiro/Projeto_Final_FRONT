document.addEventListener('DOMContentLoaded', function () {
  // Aguarda o carregamento completo do DOM (Document Object Model), garantindo que todos os elementos HTML estejam prontos para serem manipulados.

  const images = document.querySelectorAll('#slider img');
  // Seleciona todas as imagens dentro do elemento com o ID 'slider' e as armazena na variável 'images' como uma NodeList.

  let currentIndex = 0;
  // Inicializa o índice da imagem visível como 0 (primeira imagem).

  const changeTime = 3000; // Tempo de 3 segundos entre as imagens
  // Define o tempo de troca entre as imagens (3000 milissegundos = 3 segundos).

  // Função para alterar a imagem visível
  function changeImage() {
      // Remove a classe "active" da imagem atual
      images[currentIndex].classList.remove('active');
      // A classe "active" é removida da imagem que está visível, o que geralmente a faz desaparecer ou perder destaque visual.

      // Atualiza o índice para a próxima imagem (circular)
      currentIndex = (currentIndex + 1) % images.length;
      // A linha acima incrementa o índice para a próxima imagem, e o operador módulo (%) garante que o índice volte a 0 após atingir o número total de imagens (isto cria um ciclo infinito de troca de imagens).

      // Adiciona a classe "active" à nova imagem
      images[currentIndex].classList.add('active');
      // A nova imagem recebe a classe "active", o que geralmente a faz aparecer ou ganhar destaque visual.
  }

  // Inicia o intervalo de troca de imagens
  setInterval(changeImage, changeTime);
  // Utiliza o setInterval para chamar a função 'changeImage' a cada 'changeTime' milissegundos (3 segundos).
});
