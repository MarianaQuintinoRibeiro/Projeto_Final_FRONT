// Inicialize o EmailJS com o seu serviço
emailjs.init('mG9KTvplTEfGQMjpn'); // Substitua com o seu USER_ID obtido no painel do EmailJS

// Função para enviar o e-mail
document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Previne o comportamento padrão de envio do formulário

    // Pegue os dados do formulário
    var userName = document.getElementById('user_name').value; // Obtém o valor do campo 'user_name'
    var userCpf = document.getElementById('user_cpf').value; // Obtém o valor do campo 'user_cpf'
    var userAltura = document.getElementById('user_altura').value; // Obtém o valor do campo 'user_altura'
    var userPeso = document.getElementById('user_peso').value; // Obtém o valor do campo 'user_peso'

    var templateParams = {
        from_name: userName, // Define o parâmetro do nome no template de e-mail
        from_cpf: userCpf, // Define o parâmetro do CPF no template de e-mail
        from_altura: userAltura, // Define o parâmetro da altura no template de e-mail
        from_peso: userPeso, // Define o parâmetro do peso no template de e-mail
    };

    // Enviar o e-mail através do EmailJS
    emailjs.send('Senai123', 'template_tppoi6l', templateParams) // Envia o e-mail utilizando o serviço do EmailJS
        .then(function(response) {
            alert('Mensagem enviada com sucesso!'); // Exibe uma mensagem de sucesso
            console.log('Sucesso:', response); // Exibe a resposta no console
        }, function(error) {
            alert('Falha ao enviar mensagem'); // Exibe uma mensagem de erro
            console.log('Erro:', error); // Exibe o erro no console
        });
});

// Função para calcular o IMC
document.getElementById("calcularIMC").addEventListener("click", function () {
    const altura = parseFloat(document.getElementById("altura").value) / 100; // Converte a altura para metros
    const peso = parseFloat(document.getElementById("peso").value); // Obtém o valor do peso

    if (altura && peso) {
        const imc = (peso / (altura * altura)).toFixed(2); // Calcula o IMC e arredonda para 2 casas decimais
        document.getElementById("resultadoIMC").innerText = `Seu IMC é: ${imc}`; // Exibe o resultado do IMC
    } else {
        alert("Por favor, preencha os campos de altura e peso corretamente."); // Exibe um alerta se os campos não forem preenchidos corretamente
    }
});
