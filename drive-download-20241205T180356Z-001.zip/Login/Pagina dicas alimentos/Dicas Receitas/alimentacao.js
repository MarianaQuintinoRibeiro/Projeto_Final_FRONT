function menuOnClick() {
  // A função menuOnClick é chamada quando o usuário clica no botão ou ícone de menu (geralmente um menu hambúrguer).
  // Ela tem como objetivo alterar o estado de visibilidade do menu lateral e outros elementos associados.

  // O primeiro comando seleciona o elemento com o id "menu-bar" e alterna (toggle) a classe "change".
  // O método toggle() adiciona a classe "change" ao elemento se ela não estiver presente.
  // Caso contrário, remove a classe "change". Isso pode ser utilizado para animar a exibição ou ocultação do menu lateral.
  document.getElementById("menu-bar").classList.toggle("change");

  // O segundo comando seleciona o elemento com o id "nav" e também alterna a classe "change".
  // Assim como no caso anterior, a classe "change" pode ser usada para modificar o estilo do elemento.
  // Isso pode controlar a exibição da navegação (menu de links) ou a animação do menu.
  document.getElementById("nav").classList.toggle("change");

  // O terceiro comando seleciona o elemento com o id "menu-bg" e alterna a classe "change-bg".
  // Esse elemento pode estar relacionado ao fundo do menu ou a um fundo escurecido que aparece quando o menu é aberto.
  // A classe "change-bg" provavelmente altera o fundo, dando um efeito visual ao abrir o menu.
  document.getElementById("menu-bg").classList.toggle("change-bg");
}
