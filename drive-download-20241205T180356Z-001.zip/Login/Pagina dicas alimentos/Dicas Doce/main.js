function menuOnClick() {
  // Esta função é ativada quando o menu é clicado, permitindo alternar entre estados de "aberto" e "fechado".
  
  // A linha abaixo alterna a classe "change" para o elemento com o id "menu-bar".
  // Isso pode ser utilizado para animar ou mudar o estilo do menu quando ele é aberto ou fechado.
  document.getElementById("menu-bar").classList.toggle("change");
  
  // A linha abaixo alterna a classe "change" para o elemento com o id "nav".
  // Isso pode ser usado para alterar o estilo da navegação, como mostrar ou esconder o menu ou os links.
  document.getElementById("nav").classList.toggle("change");
  
  // A linha abaixo alterna a classe "change-bg" para o elemento com o id "menu-bg".
  // Geralmente, essa classe pode ser usada para alterar o fundo do menu ou da página quando o menu está ativo.
  document.getElementById("menu-bg").classList.toggle("change-bg");
}
