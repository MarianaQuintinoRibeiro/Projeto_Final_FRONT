/* Função que é chamada ao clicar no menu hambúrguer */
function menuOnClick() {
  // A função alterna (toggle) a classe "change" no elemento com id "menu-bar"
  // Isso provavelmente muda a aparência do ícone do menu hambúrguer (por exemplo, fazendo-o virar um "X")
  document.getElementById("menu-bar").classList.toggle("change");

  // A classe "change" é alternada no elemento de navegação (id="nav")
  // Isso pode ser usado para mostrar ou esconder a barra de navegação lateral
  document.getElementById("nav").classList.toggle("change");

  // A classe "change-bg" é alternada no elemento com id "menu-bg"
  // Isso pode ser usado para alterar o fundo ou o estilo do menu (por exemplo, para uma cor de fundo escura quando o menu estiver aberto)
  document.getElementById("menu-bg").classList.toggle("change-bg");
}
