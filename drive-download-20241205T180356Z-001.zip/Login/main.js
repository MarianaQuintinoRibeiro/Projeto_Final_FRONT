// main.js (para o cadastro e validação de senhas)
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("register-form");
    const senhaInput = document.getElementById("senha");
    const confirmarSenhaInput = document.getElementById("confirmar-senha");
    const errorMessage = document.getElementById("error-message");

    form.addEventListener("submit", (e) => {
        e.preventDefault();

        // Verificar se as senhas coincidem
        if (senhaInput.value !== confirmarSenhaInput.value) {
            errorMessage.textContent = "ERRO - as senhas estão diferentes!!";
            errorMessage.style.display = "block";
            return;
        }

        // Armazena os dados do usuário (localStorage simula o registro do usuário)
        const userData = {
            nome: document.getElementById("nome").value,
            sobrenome: document.getElementById("sobrenome").value,
            cpf: document.getElementById("cpf").value,
            email: document.getElementById("email").value,
            senha: senhaInput.value
        };
        localStorage.setItem("userData", JSON.stringify(userData));

        // Redireciona para login.html após cadastro bem-sucedido
        window.location.href = "login.html";
    });
});


// main.js (para login e controle de acesso)
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");
    const userBtn = document.getElementById("userBtn");
    const nutriBtn = document.getElementById("nutriBtn");
    const errorMessage = document.getElementById("error-message");

    let selectedRole = "user"; // Padrão para usuário

    userBtn.addEventListener("click", () => {
        selectedRole = "user";
        userBtn.classList.add("selected");
        nutriBtn.classList.remove("selected");
    });

    nutriBtn.addEventListener("click", () => {
        selectedRole = "nutri";
        nutriBtn.classList.add("selected");
        userBtn.classList.remove("selected");
    });

    loginForm.addEventListener("submit", (e) => {
        e.preventDefault();
        
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        // Verificação para nutricionista
        if (selectedRole === "nutri" && email === "ester@gmail.com" && password === "nutri321") {
            window.location.href = "telainicial.html"; // Redireciona o nutricionista à página inicial
            return;                //é a pagina de entrada da nutricionista
        }

        // Verificação para usuário
        if (selectedRole === "user") {
            const userData = JSON.parse(localStorage.getItem("userData"));

            if (userData && email === userData.email && password === userData.senha) {
                window.location.href = "telainicial.html"; // Redireciona o usuário à página inicial
            } else {
                errorMessage.textContent = "E-mail e senha incorretos ou úsuario não cadastrado";
                errorMessage.style.display = "block";
            }
        } else {
            errorMessage.textContent = "Acesso restrito para nutricionista.";
            errorMessage.style.display = "block";
        }
    });
});
